/* =====================================================================
   BAHASA / LANGUAGE  —  file ini berisi SEMUA teks situs.
   This file holds ALL the site's text.

   CARA EDIT / HOW TO EDIT
   1. Cari teksnya di bawah (cari kata kuncinya dengan Ctrl+F).
      Find the text below (Ctrl+F).
   2. Ubah isi  id: "..."  (Bahasa Indonesia)  atau  en: "..."  (English).
      Edit  id: "..."  (Indonesian)  or  en: "..."  (English).
   3. Simpan, lalu refresh browser. Selesai!  Save and refresh. Done!

   FORMAT TEKS / TEXT FORMAT
   - **tebal**                 -> teks tebal / bold text
   - [teks link](namaLink)     -> link; alamatnya diatur di LINKS di bawah
                                  link address is set in LINKS below
   - Jangan hapus tanda kutip " " dan koma di akhir baris.
     Don't remove the quotes " " or the comma at the end of a line.

   MENAMBAH BAHASA BARU / ADDING A NEW LANGUAGE
   - Tambahkan kode bahasa di LANGS, lalu tambahkan  xx: "..."  di setiap kunci.
     Add the code to LANGS, then add  xx: "..."  to every key.
   ===================================================================== */

/* "auto" = ikut bahasa browser pengunjung (Indonesia -> id, selain itu -> en)
   "id" / "en" = paksa satu bahasa untuk pengunjung baru */
var DEFAULT_LANG = "auto";

var LANGS = ["id", "en"];

/* Alamat link yang dipakai di dalam teks: [teks](nama) */
var LINKS = {
  vegas: "https://www.vegascreativesoftware.com/us/vegas-pro/",
  ae: "https://www.adobe.com/id_id/products/aftereffects.html",
  canon: "https://www.canon.co.uk/for_home/product_finder/cameras/digital_slr/eos_1200d/",
  tamron: "https://tamron.com.au/our-products/af-18-200mm-f-3-5-6-3-xr-di-ii-a14/",
  fusion: "https://store.steampowered.com/app/248170/Clickteam_Fusion_25/",
  blender: "https://www.blender.org/download/",
  compfest: "https://compfest.id/",
  compfestpost: "https://www.instagram.com/compfest/p/DPoJgNnEcaK/?img_index=3",
  games: "#games"
};

var TEXT = {
  /* ---------- Judul & deskripsi halaman / Page titles & descriptions ---------- */
  "title.home": {
    id: "Portofolio Deva Aditya",
    en: "Deva Aditya – Portfolio"
  },
  "title.about": {
    id: "Tentang – Deva Aditya",
    en: "About – Deva Aditya"
  },
  "title.contact": {
    id: "Kontak – Deva Aditya",
    en: "Contact – Deva Aditya"
  },
  "desc.home": {
    id: "Portofolio Deva Aditya: video editing, fotografi, dan game indie.",
    en: "Deva Aditya's portfolio: video editing, photography and indie games."
  },
  "desc.about": {
    id: "Tentang Deva Aditya: videografer, fotografer, dan game developer.",
    en: "About Deva Aditya: videographer, photographer and game developer."
  },
  "desc.contact": {
    id: "Kontak dan media sosial Deva Aditya.",
    en: "Contact details and social media of Deva Aditya."
  },

  /* ---------- Navigasi & umum / Navigation & general ---------- */
  "skip": {
    id: "Langsung ke konten",
    en: "Skip to content"
  },
  "nav.portfolio": {
    id: "Portofolio",
    en: "Portfolio"
  },
  "nav.about": {
    id: "Tentang Saya",
    en: "About Me"
  },
  "nav.contact": {
    id: "Kontak",
    en: "Contact"
  },
  "nav.menu": {
    id: "Menu",
    en: "Menu"
  },
  "nav.lang": {
    id: "Bahasa",
    en: "Language"
  },
  "footer.social": {
    id: "Media sosial",
    en: "Social media"
  },
  "footer.rights": {
    id: "Seluruh hak cipta dilindungi.",
    en: "All rights reserved."
  },

  /* ---------- Beranda (hero) / Home hero ---------- */
  "hero.hello": {
    id: "Halo, saya",
    en: "Hi, I'm"
  },
  "hero.role": {
    id: "Videografer, Fotografer, & Game Developer.",
    en: "Videographer, Photographer & Game Developer."
  },
  "hero.tagline": {
    id: "Menyampaikan cerita lewat video, foto, dan game indie — sederhana, bahkan dengan budget minim.",
    en: "Telling stories through video, photos and indie games — keeping it simple, even on a tiny budget."
  },
  "hero.cta1": {
    id: "Lihat karya",
    en: "View my work"
  },
  "hero.cta2": {
    id: "Hubungi saya",
    en: "Contact me"
  },
  "hero.badge": {
    id: "1st Runner Up – IGI Game Jam 2025",
    en: "1st Runner Up – IGI Game Jam 2025"
  },

  /* ---------- Judul bagian portofolio / Portfolio section titles ---------- */
  "sec.video": {
    id: "VIDEO",
    en: "VIDEO"
  },
  "sec.photo": {
    id: "FOTOGRAFI",
    en: "PHOTOGRAPHY"
  },
  "sec.games": {
    id: "GAME",
    en: "GAMES"
  },
  "note.new": {
    id: "Konten baru kemungkinan akan segera ditambahkan.",
    en: "New content will probably be added soon."
  },

  /* ---------- Video (judul = kartu & lightbox, .desc = deskripsi di lightbox) ---------- */
  "video.edit": {
    id: "VIDEO EDITING",
    en: "VIDEO EDITING"
  },
  "video.edit.desc": {
    id: "Kompilasi hasil editing dengan variasi gaya visual, transisi, dan efek video yang unik.",
    en: "A compilation of my edits with varied visual styles, transitions and unique video effects."
  },
  "video.game": {
    id: "GAME SHOWCASE",
    en: "GAME SHOWCASE"
  },
  "video.game.desc": {
    id: "Beberapa cuplikan game yang pernah saya buat sendiri. Lihat [selengkapnya di sini](games).",
    en: "A few clips of games I made myself. See [more here](games)."
  },
  "video.mogra": {
    id: "MOTION GRAPHICS",
    en: "MOTION GRAPHICS"
  },
  "video.mogra.desc": {
    id: "Beberapa eksperimen visual yang menampilkan animasi teks, bentuk, dan elemen grafis yang digerakkan secara dinamis menggunakan After Effects.",
    en: "Some visual experiments featuring animated text, shapes and graphic elements driven dynamically with After Effects."
  },

  /* ---------- Fotografi (alt = teks pengganti gambar) / Photography (alt text) ---------- */
  "photo.1": {
    id: "Pertandingan Basket saat Classmeet di Sekolah SMA #1",
    en: "Basketball match during the high school Classmeet #1"
  },
  "photo.2": {
    id: "Pertandingan Basket saat Classmeet di Sekolah SMA #2",
    en: "Basketball match during the high school Classmeet #2"
  },
  "photo.3": {
    id: "Petugas keamanan yang sedang berjalan di platform stasiun kereta",
    en: "A security officer walking along a train station platform"
  },
  "photo.4": {
    id: "Daun",
    en: "Leaf"
  },
  "photo.buy": {
    id: "Beli di Shutterstock",
    en: "Buy on Shutterstock"
  },

  /* ---------- Game ---------- */
  "game.robot.alt": {
    id: "Sampul game The Robot",
    en: "The Robot game cover"
  },
  "game.play.itch": {
    id: "Mainkan di itch.io",
    en: "Play on itch.io"
  },
  "game.play.gj": {
    id: "Mainkan di Game Jolt",
    en: "Play on Game Jolt"
  },

  /* ---------- Lightbox (tombol) ---------- */
  "lb.close": {
    id: "Tutup",
    en: "Close"
  },
  "lb.prev": {
    id: "Sebelumnya",
    en: "Previous"
  },
  "lb.next": {
    id: "Berikutnya",
    en: "Next"
  },

  /* ---------- Halaman Tentang / About page ---------- */
  "about.intro1": {
    id: "Halo, saya **Deva Aditya**, orang yang gemar menciptakan karya digital melalui video, mengambil foto dengan kamera, hingga mencoba animasi 3D, dan juga bikin game indie sendiri!",
    en: "Hi, I'm **Deva Aditya**, someone who loves creating digital work through video, taking photos with a camera, experimenting with 3D animation, and making my own indie games!"
  },
  "about.intro2": {
    id: "Bagi saya, itu adalah cara untuk menyampaikan cerita dengan lebih jelas dan menarik, serta menghadirkan pengalaman yang berkesan bagi siapa pun yang melihatnya.",
    en: "For me, it's a way to tell stories more clearly and engagingly, and to create a memorable experience for anyone who sees them."
  },
  "about.intro3": {
    id: "Dan saya juga senang bereksperimen, terutama mencari cara bagaimana sebuah karya bisa terwujud dengan sederhana, bahkan dengan budget yang minim sekalipun.",
    en: "I also enjoy experimenting, especially finding ways to make a piece come to life simply, even on a minimal budget."
  },
  "about.skills": {
    id: "KEMAMPUAN",
    en: "SKILLS"
  },
  "skill.video.t": {
    id: "VIDEO EDITOR",
    en: "VIDEO EDITOR"
  },
  "skill.video.d": {
    id: "Mahir menggunakan [VEGAS Pro 18](vegas) dalam editing video, dan [After Effects](ae) untuk pembuatan motion graphic sederhana.",
    en: "Skilled with [VEGAS Pro 18](vegas) for video editing, and [After Effects](ae) for simple motion graphics."
  },
  "skill.photo.d": {
    id: "Alat yang kugunakan adalah [Canon EOS 1200D](canon) dan [lensa Tamron AF 18-200 mm for Canon](tamron).",
    en: "My gear is a [Canon EOS 1200D](canon) and a [Tamron AF 18-200 mm lens for Canon](tamron)."
  },
  "skill.game.t": {
    id: "GAME DEVELOPER",
    en: "GAME DEVELOPER"
  },
  "skill.game.d": {
    id: "Saya membuat dan mengembangkan game menggunakan [Clickteam Fusion 2.5](fusion).",
    en: "I design and develop games using [Clickteam Fusion 2.5](fusion)."
  },
  "skill.3d.t": {
    id: "ANIMASI 3D",
    en: "3D ANIMATION"
  },
  "skill.3d.d": {
    id: "Memiliki pemahaman dasar animasi dan pembuatan model 3D sederhana pada software [Blender](blender).",
    en: "I have a basic understanding of animation and simple 3D modeling in [Blender](blender)."
  },
  "about.awards": {
    id: "PENGHARGAAN",
    en: "AWARDS"
  },
  "award.1": {
    id: "[COMPFEST 17](compfest) – [1st Runner Up IGI Game Jam 2025.](compfestpost)",
    en: "[COMPFEST 17](compfest) – [1st Runner Up IGI Game Jam 2025.](compfestpost)"
  },
  "about.exp": {
    id: "PENGALAMAN",
    en: "EXPERIENCE"
  },
  "exp.1.t": {
    id: "Dokumentasi, Karang Taruna (2025)",
    en: "Documentation, Karang Taruna – Youth Organization (2025)"
  },
  "exp.1.d": {
    id: "Mendokumentasikan kegiatan lomba Hari Kemerdekaan 17 Agustus, sekaligus mengelola 500 foto untuk memastikan setiap gambar tersaji dengan menarik.",
    en: "Documented the 17 August Independence Day competitions and managed 500 photos, making sure every image was presented attractively."
  },
  "exp.2.t": {
    id: "Video Editor, Tim Kreatif ARGYROS Cup (2024)",
    en: "Video Editor, ARGYROS Cup Creative Team (2024)"
  },
  "exp.2.d": {
    id: "Saya membantu mengedit video promosi untuk event sekolah ini, meskipun batal diselenggarakan sesudah video diproduksi.",
    en: "I helped edit the promo video for this school event, although it was cancelled after the video was produced."
  },

  /* ---------- Halaman Kontak / Contact page ---------- */
  "contact.h": {
    id: "KONTAK SAYA",
    en: "CONTACT ME"
  },
  "contact.lead": {
    id: "Ada proyek atau ingin berkolaborasi? Kirim pesan, saya senang mengobrol.",
    en: "Got a project or want to collaborate? Send a message, I'd love to chat."
  },
  "contact.social": {
    id: "MEDIA SOSIAL",
    en: "SOCIAL MEDIA"
  },
  "contact.copy": {
    id: "Salin",
    en: "Copy"
  },
  "contact.copied": {
    id: "Disalin!",
    en: "Copied!"
  }
};

/* =====================================================================
   app.js — logika situs (ES5, kompatibel dengan browser lama)
   Teks/bahasa ada di lang.js, bukan di sini.
   ===================================================================== */
(function () {
  "use strict";

  var doc = document, root = doc.documentElement, body = doc.body;

  function $(s, c) { return (c || doc).querySelector(s); }
  function $$(s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); }
  function on(el, ev, fn) { if (el) { el.addEventListener(ev, fn, false); } }
  function hasCls(el, c) { return (" " + el.className + " ").indexOf(" " + c + " ") > -1; }
  function setCls(el, c, add) {
    var has = hasCls(el, c);
    if (add && !has) { el.className = (el.className + " " + c).replace(/^\s+/, ""); }
    if (!add && has) { el.className = (" " + el.className + " ").replace(" " + c + " ", " ").replace(/^\s+|\s+$/g, ""); }
  }
  function store(k, v) {
    try { if (v === undefined) { return window.localStorage.getItem(k); } window.localStorage.setItem(k, v); } catch (e) { }
    return null;
  }

  /* ---------------------------------------------------------------
     BAHASA (teks diambil dari TEXT di lang.js)
     --------------------------------------------------------------- */
  var lang = "id";
  var hasText = typeof TEXT !== "undefined" && typeof LINKS !== "undefined";

  function t(key) {
    var e = hasText && TEXT[key];
    return e ? (e[lang] || e.id || key) : key;
  }

  // **tebal** dan [teks](namaLink) -> HTML aman
  function fmt(s) {
    s = s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
    s = s.replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");
    return s.replace(/\[([^\]]+)\]\(([^)]+)\)/g, function (m, txt, k) {
      var u = LINKS[k];
      if (!u) { return txt; }
      if (u.charAt(0) === "#") { return '<a href="' + u + '" class="js-int">' + txt + "</a>"; }
      return '<a href="' + u + '" target="_blank" rel="noopener">' + txt + "</a>";
    });
  }

  function pickLang() {
    var saved = store("lang");
    if (saved && LANGS.indexOf(saved) > -1) { return saved; }
    if (DEFAULT_LANG !== "auto" && LANGS.indexOf(DEFAULT_LANG) > -1) { return DEFAULT_LANG; }
    var nav = (navigator.language || navigator.userLanguage || "id").toLowerCase();
    var short = nav.split("-")[0];
    if (short === "in") { short = "id"; } // kode lama untuk Indonesia
    return LANGS.indexOf(short) > -1 ? short : (LANGS.indexOf("en") > -1 ? "en" : LANGS[0]);
  }

  function applyLang(l) {
    lang = l;
    root.setAttribute("lang", l);
    $$("[data-i18n]").forEach(function (el) {
      var k = el.getAttribute("data-i18n");
      if (TEXT[k]) { el.innerHTML = fmt(t(k)); }
    });
    $$("[data-i18n-alt]").forEach(function (el) { el.setAttribute("alt", t(el.getAttribute("data-i18n-alt"))); });
    $$("[data-i18n-aria]").forEach(function (el) { el.setAttribute("aria-label", t(el.getAttribute("data-i18n-aria"))); });
    var tk = body.getAttribute("data-title");
    if (tk) { doc.title = t(tk); }
    var dk = body.getAttribute("data-desc"), meta = $('meta[name="description"]');
    if (dk && meta) { meta.setAttribute("content", t(dk)); }
    $$(".lang button").forEach(function (b) {
      var active = b.getAttribute("data-lang") === l;
      b.setAttribute("aria-pressed", active ? "true" : "false");
      setCls(b, "on", active);
    });
    if (typeof refreshLightboxText === "function") { refreshLightboxText(); }
  }

  /* ---------------------------------------------------------------
     MENU MOBILE
     --------------------------------------------------------------- */
  var hdr = $("#hdr"), burger = $("#burger");
  function setMenu(open) {
    setCls(hdr, "open", open);
    burger.setAttribute("aria-expanded", open ? "true" : "false");
  }
  on(burger, "click", function () { setMenu(!hasCls(hdr, "open")); });
  $$("#menu a").forEach(function (a) { on(a, "click", function () { setMenu(false); }); });
  on(window, "resize", function () { if (window.innerWidth >= 700) { setMenu(false); } });

  /* ---------------------------------------------------------------
     DETEKSI WEBP (untuk gambar lightbox; fallback ke JPG)
     --------------------------------------------------------------- */
  var webp = false;
  (function () {
    var i = new Image();
    i.onload = function () { webp = i.width === 1; };
    i.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA";
  })();

  /* ---------------------------------------------------------------
     VIDEO KARTU: putar hanya saat terlihat, hemat data & baterai
     --------------------------------------------------------------- */
  var autos = $$("video.auto");
  function playV(v) { var p = v.play(); if (p && p["catch"]) { p["catch"](function () { }); } }
  function pauseAuto() { autos.forEach(function (v) { v.pause(); }); }
  function resumeAuto() { autos.forEach(function (v) { if (v._vis) { playV(v); } }); }

  (function () {
    var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var c = navigator.connection || {};
    var slow = c.saveData === true || /(^|-)2g$/.test(c.effectiveType || "");
    if (!autos.length || !("IntersectionObserver" in window) || reduce || slow) { return; } // tetap tampil sebagai poster
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        var v = en.target;
        v._vis = en.isIntersecting;
        if (en.isIntersecting) {
          if (!v.getAttribute("src")) { v.muted = true; v.src = v.getAttribute("data-src"); }
          if (!lbOpen()) { playV(v); }
        } else { v.pause(); }
      });
    }, { rootMargin: "80px" });
    autos.forEach(function (v) { io.observe(v); });
    on(doc, "visibilitychange", function () { if (doc.hidden) { pauseAuto(); } else if (!lbOpen()) { resumeAuto(); } });
  })();

  /* ---------------------------------------------------------------
     LIGHTBOX (umum)
     --------------------------------------------------------------- */
  var plb = $("#plb"), vlb = $("#vlb"), opener = null;
  function lbOpen() { return (plb && hasCls(plb, "show")) || (vlb && hasCls(vlb, "show")); }
  function openBox(box, from) {
    opener = from || null;
    setCls(box, "show", true);
    box.setAttribute("aria-hidden", "false");
    setCls(body, "noscroll", true);
    pauseAuto();
    var x = $(".lb-x", box); if (x) { x.focus(); }
  }
  function closeBox(box) {
    setCls(box, "show", false);
    box.setAttribute("aria-hidden", "true");
    setCls(body, "noscroll", false);
    resumeAuto();
    if (opener && opener.focus) { opener.focus(); }
  }
  function trap(e, box) { // fokus keyboard tetap di dalam lightbox
    var f = $$("button, a[href]", box).filter(function (el) { return el.offsetWidth > 0; });
    if (!f.length) { return; }
    var first = f[0], last = f[f.length - 1];
    if (e.shiftKey && doc.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && doc.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  function swipe(box, fn) {
    var x0 = null;
    on(box, "touchstart", function (e) { x0 = e.touches[0].clientX; });
    on(box, "touchend", function (e) {
      if (x0 === null) { return; }
      var dx = e.changedTouches[0].clientX - x0; x0 = null;
      if (Math.abs(dx) > 60) { fn(dx < 0 ? 1 : -1); }
    });
  }

  /* ---------------------------------------------------------------
     LIGHTBOX FOTO
     --------------------------------------------------------------- */
  var photos = $$(".ph"), pcur = 0;
  function showPhoto(i) {
    pcur = (i + photos.length) % photos.length;
    var a = photos[pcur], img = $("#plb-img"), buy = $("#plb-buy"), b = a.getAttribute("data-buy");
    img.style.opacity = ".35";
    img.onload = function () { img.style.opacity = "1"; };
    img.src = a.getAttribute("data-full") + (webp ? ".webp" : ".jpg");
    img.alt = $("img", a).alt;
    if (b) { buy.href = b; buy.style.display = ""; } else { buy.style.display = "none"; }
    $("#plb-n").textContent = (pcur + 1) + " / " + photos.length;
  }
  if (plb && photos.length) {
    photos.forEach(function (a, i) {
      on(a, "click", function (e) { e.preventDefault(); showPhoto(i); openBox(plb, a); });
    });
    on($("#plb-x"), "click", function () { closeBox(plb); });
    on($("#plb-prev"), "click", function () { showPhoto(pcur - 1); });
    on($("#plb-next"), "click", function () { showPhoto(pcur + 1); });
    on(plb, "click", function (e) { if (e.target === plb || e.target.className === "lb-stage") { closeBox(plb); } });
    swipe(plb, function (d) { showPhoto(pcur + d); });
  }

  /* ---------------------------------------------------------------
     LIGHTBOX VIDEO
     --------------------------------------------------------------- */
  var cards = $$(".vcard"), vcur = 0, vv = $("#vlb-v");
  function refreshLightboxText() {
    if (plb && photos.length && hasCls(plb, "show")) { $("#plb-img").alt = $("img", photos[pcur]).alt; }
    if (!vlb || !hasCls(vlb, "show")) { return; }
    var k = cards[vcur].getAttribute("data-key");
    $("#vlb-t").innerHTML = fmt(t(k));
    $("#vlb-d").innerHTML = fmt(t(k + ".desc"));
  }
  function showVideo(i) {
    vcur = (i + cards.length) % cards.length;
    var c = cards[vcur];
    vv.pause();
    vv.poster = c.getAttribute("data-poster");
    vv.src = c.getAttribute("data-vid");
    playV(vv);
    refreshLightboxText();
  }
  function closeVideo() {
    vv.pause(); vv.removeAttribute("src"); vv.load(); // bebaskan memori
    closeBox(vlb);
  }
  if (vlb && cards.length) {
    cards.forEach(function (c, i) {
      on(c, "click", function () { openBox(vlb, c); showVideo(i); });
    });
    on($("#vlb-x"), "click", closeVideo);
    on($("#vlb-prev"), "click", function () { showVideo(vcur - 1); });
    on($("#vlb-next"), "click", function () { showVideo(vcur + 1); });
    on(vlb, "click", function (e) { if (e.target === vlb) { closeVideo(); } });
    // link internal di dalam deskripsi (mis. "selengkapnya di sini")
    on(vlb, "click", function (e) {
      var a = e.target;
      if (a && hasCls(a, "js-int")) {
        e.preventDefault();
        var id = a.getAttribute("href").slice(1);
        closeVideo();
        setTimeout(function () { var el = doc.getElementById(id); if (el && el.scrollIntoView) { el.scrollIntoView(); } }, 60);
      }
    });
  }

  /* Keyboard: Esc, panah kiri/kanan, Tab */
  on(doc, "keydown", function (e) {
    var k = e.key || e.keyCode;
    var box = (plb && hasCls(plb, "show")) ? plb : ((vlb && hasCls(vlb, "show")) ? vlb : null);
    if (k === "Escape" || k === "Esc" || k === 27) {
      if (box === plb) { closeBox(plb); } else if (box === vlb) { closeVideo(); } else { setMenu(false); }
    } else if (box && (k === "ArrowLeft" || k === "Left" || k === 37) && e.target.tagName !== "VIDEO") {
      if (box === plb) { showPhoto(pcur - 1); } else { showVideo(vcur - 1); }
    } else if (box && (k === "ArrowRight" || k === "Right" || k === 39) && e.target.tagName !== "VIDEO") {
      if (box === plb) { showPhoto(pcur + 1); } else { showVideo(vcur + 1); }
    } else if (box && (k === "Tab" || k === 9)) { trap(e, box); }
  });

  /* ---------------------------------------------------------------
     TOMBOL SALIN (halaman kontak)
     --------------------------------------------------------------- */
  function copyText(s, done) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(s).then(done, function () { fallbackCopy(s, done); });
    } else { fallbackCopy(s, done); }
  }
  function fallbackCopy(s, done) {
    var ta = doc.createElement("textarea");
    ta.value = s; ta.setAttribute("readonly", ""); ta.style.cssText = "position:fixed;left:-999px;top:0;opacity:0";
    body.appendChild(ta); ta.select();
    try { ta.setSelectionRange(0, 999); doc.execCommand("copy"); done(); } catch (e) { }
    body.removeChild(ta);
  }
  $$("[data-copy]").forEach(function (b) {
    on(b, "click", function () {
      copyText(b.getAttribute("data-copy"), function () {
        var m = $("#copy-msg"); if (!m) { return; }
        m.textContent = t("contact.copied");
        setTimeout(function () { m.textContent = ""; }, 2000);
      });
    });
  });

  /* ---------------------------------------------------------------
     INIT
     --------------------------------------------------------------- */
  if (hasText) {
    $$(".lang button").forEach(function (b) {
      on(b, "click", function () {
        var l = b.getAttribute("data-lang");
        store("lang", l);
        applyLang(l);
      });
    });
    applyLang(pickLang());
  } else {
    $$(".lang").forEach(function (el) { el.style.display = "none"; });
  }
})();

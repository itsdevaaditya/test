# Portofolio Deva Aditya (versi ringan)

Buka `index.html` langsung di browser, atau upload seluruh folder ke Netlify.

## Ganti teks / bahasa
Semua teks ada di **`lang.js`** (cari dengan Ctrl+F). Ubah `id: "..."` (Indonesia)
atau `en: "..."` (English). Link di dalam teks diatur di `LINKS` (bagian atas file).
`DEFAULT_LANG` = "auto" (ikut bahasa browser), "id", atau "en".

## Ganti warna
Bagian paling atas `style.css` (`:root`).

## Tambah / ganti media
- Foto: simpan versi `nama.webp` + `nama.jpg` (maks 1600px) dan `nama-480.webp` + `nama-480.jpg` (thumbnail).
- Video: `nama.mp4` (720p), `nama-clip.mp4` (klip loop 8 detik tanpa suara, 480p), `nama.jpg` (poster).
- Salin blok `<a class="ph">` / `<button class="vcard">` di `index.html`, lalu tambahkan teksnya di `lang.js`.
